package com.example.nineSliceScaling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
