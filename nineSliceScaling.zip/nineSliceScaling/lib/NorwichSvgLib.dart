import 'package:flutter/material.dart';

// A heloper library for miscellanious SVG functions
class NorwichSvgLib {
  // Scale the supplied SVG path according to 9-slice scaling
  // such that the geometry in the corners is protected
  // and the geometry in the other five parts is scaled
  // see https://en.wikipedia.org/wiki/9-slice_scaling
  static Path sliceScale(Path path, Rect centreSlice, Size newSize) {
    final Rect pathBounds = path.getBounds();

    double scaleWidth = newSize.width / pathBounds.width;
    double scaleHeight = newSize.height / pathBounds.height;

    // TODO: replace next line with implementation of 9-slice scaling
    path = scale(path, newSize);

    return path;
  }

  // scale the path according to scale factor and offset specified by width
  // height, offsetX and offsetY parameters respectively
  static Path scaleFromLTWH(
      Path path, double offsetX, double offsetY, double width, double height) {
    return scaleFromOS(path, Offset(offsetX, offsetY), Size(width, height));
  }

  // scale the path according to scale factor and offset specified by size
  // and offset parameters respectively
  static Path scaleFromOS(Path path, Offset offset, Size size) {
    return _scale(path, offset & size);
  }

  // scale the path according to scale factor and offset specified by rect
  static Path _scale(Path path, Rect rect) {
    final Matrix4 scaleMatrix = Matrix4.identity();
    scaleMatrix.scale(rect.width, -rect.height);
    path = path.transform(scaleMatrix.storage);

    path = path.shift(Offset(rect.left, rect.top));
    return path;
  }

  // scale the path to the dimensions provided by newSize
  static Path scale(Path path, Size newSize) {
    final Rect pathBounds = path.getBounds();
    double scaleWidth = newSize.width / pathBounds.width;
    double scaleHeight = newSize.height / pathBounds.height;

    return scaleFromLTWH(path, 0.0, newSize.height, scaleWidth, scaleHeight);
  }
}
