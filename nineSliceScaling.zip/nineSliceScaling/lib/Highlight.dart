import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_drawing/path_drawing.dart';

import 'NorwichSvgLib.dart';

/// A widget which displays a highlight panel with an inner widget
class Highlight extends StatefulWidget {
  // default size of the widget
  static Size _defaultSize = Size(57, 44);
  // offset to the start of the text area
  static Size _defaultOffset = Size(18, 10);
  // defaul text area size
  static Size _defaultTextArea = Size(23, 14);

  static Size _size;
  static Size _offset;
  // ignore: unused_field
  static Size _textArea;

  final Color outerColor;
  final Color innerColor;
  final Text child;

  final bool animate;

  Highlight({
    this.outerColor = Colors.black,
    this.innerColor = Colors.yellow,
    @required this.child,
    this.animate = false,
  }) {
    assert(outerColor != null);
    assert(innerColor != null);
  }

  @override
  _HighlightState createState() => _HighlightState();

  static Size get size {
    return Highlight._defaultSize;
  }
}

class _HighlightState extends State<Highlight> with TickerProviderStateMixin {
  AnimationController _controller;
  Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    _animation = Tween(begin: 1.0, end: 0.0).animate(_controller)
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          _controller.reverse();
        } else if (status == AnimationStatus.dismissed) {
          _controller.forward();
        }
      });

    if (widget.animate) {
      _controller.forward();
    }
  }

  @override
  dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Work out the size of our text box
    final Size childSize = (TextPainter(
            text: TextSpan(text: widget.child.data, style: widget.child.style),
            //widget.child.textSpan,
            maxLines: 1,
            textScaleFactor: MediaQuery.of(context).textScaleFactor,
            textDirection: TextDirection.ltr)
          ..layout())
        .size;

    double expandedWidth = (childSize.width - Highlight._defaultTextArea.width);
    double expandedHeight =
        (childSize.height - Highlight._defaultTextArea.height);

    double newSizeWidth = Highlight._defaultSize.width;
    double newSizeHeight = Highlight._defaultSize.height;
    double newTextAreaWidth = Highlight._defaultTextArea.width;
    double newTextAreaHeight = Highlight._defaultTextArea.height;
    double newOffsetWidth = Highlight._defaultOffset.width;
    double newOffsetHeight = Highlight._defaultOffset.height;

    if (expandedWidth > 0) {
      newSizeWidth += expandedWidth * 1.5;
      newOffsetWidth *= 1.5;
      newTextAreaWidth += expandedWidth;
    }
    if (expandedHeight > 0) {
      newSizeHeight += expandedHeight * 1.5;
      newOffsetHeight *= 1.5;
      newTextAreaHeight += expandedHeight;
    }
    Highlight._size = Size(newSizeWidth, newSizeHeight);
    Highlight._textArea = Size(newTextAreaWidth, newTextAreaHeight);
    Highlight._offset = Size(newOffsetWidth, newOffsetHeight);

    return FadeTransition(
      opacity: _animation,
      child: DecoratedBox(
        decoration: BoxDecoration(
            //border: Border.all(color: Colors.red, width: 1.0),
            ),
        //child: //SizedBox(
        //width: 100,
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: _highlight(),
        ),
        //),
      ),
    );
  }

  Widget _highlight() {
    return Container(
      constraints: BoxConstraints.expand(
          width: Highlight._size.width, height: Highlight._size.height),
      child: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            width: Highlight._size.width,
            height: Highlight._size.height,
            child: CustomPaint(
              painter: HighlightPainter(widget),
            ),
          ),
          Positioned(
            top: Highlight._offset.height,
            left: Highlight._offset.width,
            //width: 100,
            child: widget.child,
          ),
        ],
      ),
    );
  }
}

class HighlightPainter extends CustomPainter {
  final Highlight points;

  HighlightPainter(this.points);

  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.style = PaintingStyle.fill;

    Path path = parseSvgPathData(
        "M0 220 m0 -220 m285 0 m285 0 m0 220 m0 220 m-285 0 m-285 0 m0 -220z" +
            " M170 394 c-83 -36 -138 -130 -127 -221 6 -58 45 -99 111 -118 58 -17" +
            " 194 -20 250 -4 51 14 124 82 132 123 12 65 -49 154 -140 207 -43 24 -62 29" +
            " -121 29 -40 -1 -85 -7 -105 -16z m204 -18 c45 -19 73 -57 87 -122 16 -69 -1" +
            " -111 -62 -151 -37 -24 -53 -28 -139 -31 l-98 -4 -37 34 c-32 29 -38 42 -42 84" +
            " -8 80 38 154 117 188 44 19 131 20 174 2z");

    Path innerPath = parseSvgPathData(
        "M0 220 m0 -220 m285 0 m285 0 m0 220 m0 220 m-285 0 m-285 0 m0 -220z" +
            " m423 166 c67 -33 107 -78 107 -120" +
            " 0 -40 -36 -121 -67 -148 -47 -42 -114 -62 -218 -62 -114 0 -132 6 -175 66 -26 35 -30 50 -30 105 0 60 2 65 41" +
            " 104 65 65 108 80 214 77 63 -3 101 -9 128 -22z");

    Rect rect = Offset(0, 0) & Highlight._defaultTextArea;

    // scale
    path = NorwichSvgLib.sliceScale(path, rect, size);
    innerPath = NorwichSvgLib.sliceScale(innerPath, rect, size);

    //draw the background
    paint.color = points.innerColor;
    canvas.drawPath(innerPath, paint);

    // draw the border (outer path) over the background (inner path)
    paint.color = points.outerColor;
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
